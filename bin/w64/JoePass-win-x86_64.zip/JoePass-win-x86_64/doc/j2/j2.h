#ifndef __J2__
#define __J2__

#define J2_OUTPUT_FIlE	"j2.out"

int j2( int argc, char **argv);


#endif