How to support a new language in JoePass:

Make a copy of the folder with a language you understand.
Give it the name of the new language.
Translate the content of the folder into the new language, including this file.
Please send a copy of the new folder to westwolf@gmx.de.

Hints: 
a)
In the file jpLanguage.txt:
Ignore the first two lines. They look like this:
 Preference file
 generated Fri Mar  5 20:23:41 2004
the syntax is
 Variable:= TEXT
Translate TEXT into your language.
There must be ONE space character before TEXT.
b)
Don�t use country specific characters, as they are system dependend.


Wolfgang Westerboer


Uebersetzt von