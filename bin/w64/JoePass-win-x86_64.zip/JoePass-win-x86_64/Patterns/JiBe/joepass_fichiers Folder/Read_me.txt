passing patterns for JoePass! from the French website :
http://perso.club-internet.fr/gibee

This folder follows the site's structure and has the following
sub-directories.

- rythmes : passing patterns for 2 jugglers.

- postes_et_derives_N_W : feed patterns in V, N, W or line (typewriter) feeds. 

- plusieurs : passing from 3 to 8 (or more) jugglers.  

- apprendre : passing patterns useful for the learning process.


The following abbreviations are combined to name the files :

- 3j : 3 jugglers (same for 4j, 5j...)
- 8m : 8 clubs (total nuber of clubs in the passing pattern, same for 9m, 10m...)
- 2t : 2-count (rhythm, same for 3t, pps, pph)
- slowfast_2t-3t : slowfast between 2-count and 3-count rhythms.
- posteN ou posteW : feed in a N or W pattern.

Most of the passing patterns are explained (in french) on the website. Do not hesitate
to check it out or to mail me for details.

JiBe
------------------------------------------------
gibee@club-internet.fr
http://perso.club-internet.fr/gibee/passing.htm
-------------------------------------------------