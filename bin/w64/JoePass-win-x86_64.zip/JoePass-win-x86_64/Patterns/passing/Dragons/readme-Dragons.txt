Hi everyone,

At Passout X in San Diego, there was a fair amount of interest in the holy
grail patterns (breakdowns for learning 2.5p 3.5p 4.5p).

One of the hard things about juggling the holy grail is the 4.5p
2.5pcombination. Daniel titled the basic breakdown 4.5p
2.5p 1, "the dragon" because it's the hardest of the grail breakdowns and
you must beat the dragon to attain the holy grail. Since then, the
combination 4.5p 2.5p has been dubbed "dragon". So, I suppose the "baby
dragon" (see below) could be explained as "dragon zip zip zip", and the
baby dragon twins would be "dragon dragon zip" or simply "double-dragon
zip".

Anyway, at Passout Daniel Shultz and I wrote down a bunch of good dragon
patterns, and I figured I would share them here.

Enjoy,

-Amiel


4 clubs
baby dragon       4.5p 2.5p 1 1 1

5 clubs

young ugly dragon       4.5p   2.5p   1

                          4.5p    2.5p   0
(995520)

baby dragon...
w/pajamas                 4.5p 2.5p 3.5p 1 1
goes to the zoo           4.5p 2.5p 1 3.5p 1
w/fuzzybunnyslippers      4.5p 2.5p 1 1 3.5p

6 clubs
raaaar!                   4.5p 2.5p 3.5p 3.5p 1
grrrrrr!                  4.5p 2.5p 3.5p 1 3.5p
prshhhhh!                 4.5p 2.5p 1 3.5p 3.5p

baby dragon twins         4.5p 2.5p 4.5p 2.5p 1

the dragon                4.5p 2.5p 1

7 clubs
dragon 3cnt               4.5p 2.5p 3.5p 3.5p 3.5p

willy wonka's holy grail  3.5p 4.5p 2.5p
-------------- next part --------------
An HTML attachment was scrubbed...
URL: <http://lists.takeouts.eu/private/pass-out/attachments/20130115/8c9debef/attachment.html>
_______________________________________________
pass-out mailing list
pass-out@lists.takeouts.eu
http://lists.takeouts.eu/listinfo/pass-out
