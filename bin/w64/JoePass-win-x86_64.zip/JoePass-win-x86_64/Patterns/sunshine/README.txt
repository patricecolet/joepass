"10 January 2003

This folder contains a set of JoePass! files from the Mount Clemens
Juggling Club web site:

http://www.mcjugglers.org/patterns/

Please send comments to: Eric Sunshine <eric@ericsunshine.com>
Copyright (C)2003 by Eric Sunshine


TABLE OF CONTENTS
-----------------
1. Sunshine Series
  1.1. Scattered Sunshine (scatteredsunshine.pass)
  1.2. Very Scattered Sunshine (veryscatteredsunshine.pass)
  1.3. Shattered Sunshine (shatteredsunshine.pass)
    1.3.1. Mild Shattered Sunshine (mildshatteredsunshine.pass)
    1.3.2. Shattered Sunshine Site-Swaps
           (shatteredsunshine-feedee-earlydouble1.pass)
           (shatteredsunshine-feedee-earlydouble2.pass)
           (shatteredsunshine-feedees-late-doubles.pass)
  1.4. Shattered Scattered Sunshine
       (shatteredscatteredsunshine1.pass)
    1.4.1. Shattered Scattered Sunshine variation 1
           (shatteredscatteredsunshine2.pass)
    1.4.2. Mild Shattered Scattered Sunshine
           (mildshatteredscatteredsunshine.pass)
  1.5. Splattered Sunshine (splatteredsunshine.pass)
    1.5.1. Mild Splattered Sunshine (mildsplatteredsunshine.pass)

2. Other Interesting Patterns
  2.1. Martin Series
    2.1.1. Martin's Madness (martinsmadness.pass)
    2.1.2. Martin's Mildness (martinsmildness.pass)
    2.1.3. Martin's Ultimates (martinsultimates.pass)
  2.2. Jim's 3-Count (jims3count.pass)
  2.3. Keith's 3-Count Feed (keiths3countfeed.pass)

3. Site-Swaps
  3.1. 3-Count: Early Quad (3count-earlyquad.pass)
  3.2. 3-Count: Late Quad (3count-latequad.pass)
  3.3. 3-Count Feed: Feedees Throw Late Doubles
       (3countfeed-feedeesthrowlates.pass)


----------------------------------------
1. Sunshine Series

This is a set of patterns created by Eric Sunshine beginning around
1998 or 1999.  Families of these patterns tend to share certain
characteristics and, in some cases, the families marry with
particularly pleasing results.  Many of these patterns were inspired
by the Martin's Madness feed, in which the feeder is forced
periodically to perform a hand-off.  A feature of most of the Sunshine
series of patterns is that two or more jugglers are forced to perform
hand-offs, and in many cases, the feeder must juggle Ultimates
(1-count) with a hand-off.  The skill level required for most of the
patterns ranges from Jim's 3-count to 1-count with a hand-off.  For
pedagogical purposes, it is recommended that you view these patterns
via the causal editor.


----------------------------------------
1.1. Scattered Sunshine  (scatteredsunshine.pass)

This pattern was devised by Eric Sunshine sometime during 1998 or 1999
shortly after learning Martin's Madness.

The basic Scattered Sunshine feed is a three person pattern in which
two jugglers are doing hand-offs every six beats.  The feeder performs
Ultimates (1-count) with a hand-off.  Feedee A performs Martin's
Mildness, which is a pass-pass-self pattern with a hand-off.  Feedee B
performs a modified Jim's 3-count in which passes alternate between
straight and diagonal.  One way to visualize this pattern is to start
with Martin's Mildness between the feeder and feedee A, and then add
feedee B in place of the feeder's self-throw.

It is possible to train the feedees for this pattern independent of
the pattern itself.  Feedee A can be trained via Martin's Mildness.
Feedee B can be trained via a modified Jim's 3-count in which passes
alternate between straight and diagonal.

A nice feature of this feed, as with many others, is that it can be
extended easily by adding jugglers to each end.  For example, if a
Jim's 3-count feedee is added to feedee A's end, then feedee A turns
into a Scattered Sunshine feeder (that is, Ultimates with a hand-off).
Adding a 3-count feedee to feedee B's end causes feedee B to turn into
a Martin's Madness feeder.  Likewise, it is possible to add a
pass-pass-self feedee to feedee B's end, which will cause feedee B to
perform Ultimates.


----------------------------------------
1.2. Very Scattered Sunshine  (veryscatteredsunshine.pass)

This pattern was devised by Eric Sunshine in 2001.

The basic Very Scattered Sunshine feed is a four person pattern.  The
feeder does Ultimates (1-count) with a hand-off every six beats.  The
feedees on the left and right ends, feedees A and C, do standard Jim's
3-count with straight passes.  Feedee B, the inside or middle feedee,
does a modified Jim's 3-count in which passes alternate between
straight and diagonal throws.  One way to visualize this pattern is to
take the Martin's Madness feed and insert a third feedee in place of
the feeder's self-throw.

It is possible to train the feedees for this pattern independent of
the pattern itself.  Feedees A and C can be trained via vanilla Jim's
3-count.  Feedee B can be trained via a modified Jim's 3-count in
which passes alternate between straight and diagonal.


----------------------------------------
1.3. Shattered Sunshine  (shatteredsunshine.pass)

This pattern was devised by Eric Sunshine on 2002/12/11.

The basic Shattered Sunshine feed is a three person pattern.  The
feeder does Ultimates (1-count).  Feedees A and B each toggle between
3-count for 3 beats and pass-pass-self for three beats.

1.3.1. Mild Shattered Sunshine  (mildshatteredsunshine.pass)

Mild Shattered Sunshine is used to to train the feedees for Shattered
Sunshine.  Feedee A is trained via a pass-pass-self-pass-self-self
pattern.  Feedee B is trained via a self-self-pass-self-pass-pass
pattern.  Though similar, the feedee positions are inversions of one
another, thus it is necessary to train each feedee separately.  This
is illustrated in mildshatteredsunshine.pass by the two distinct sets
of jugglers.

1.3.2. Shattered Sunshine Site-Swaps
       (shatteredsunshine-feedee-earlydouble1.pass)
       (shatteredsunshine-feedee-earlydouble2.pass)
       (shatteredsunshine-feedees-late-doubles.pass)

Various site-swap tricks can be thrown in a Shattered Sunshine feed.
The file shatteredsunshine-feedee-earlydouble1.pass shows how feedee A
can throw an early double to the feeder during the feedee's 3-count
phase.  The file shatteredsunshine-feedee-earlydouble2.pass shows how
feedee A can throw an early double to the feeder during the feedee's
pass-pass-self phase.  The file
shatteredsunshine-feedees-late-doubles.pass shows how feedees A and B
can cooperate to throw back-to-back late doubles to the feeder.  The
feedees must cooperate in order to avoid having two clubs arrive at
one of the feeder's hands at a given beat.


----------------------------------------
1.4. Shattered Scattered Sunshine  (shatteredscatteredsunshine1.pass)

This pattern was devised by Eric Sunshine on 2002/12/12.

The basic Shattered Scattered Sunshine feed is a three person pattern
in which all jugglers do hand-offs every six beats.  This pattern is
an elegant marriage of the Shattered Sunshine and Scattered Sunshine
feeds.  The feeder does Ultimates (1-count) with a hand-off.  Feedee
A's pattern is pass-pass-self-pass-self-self, and throws straight
passes to the feeder.  Feedee B's pattern is
self-self-pass-self-pass-pass, and throws diagonal passes.

1.4.1. Shattered Scattered Sunshine variation 1
       (shatteredscatteredsunshine2.pass)

A slightly simpler variation of the basic Shattered Scattered Sunshine
pattern has both feedees throwing straight passes, and the feeder
always throwing diagonal passes.  This differs from the basic pattern
in which one feedee throws straight passes and the other throws
diagonals.

1.4.2. Mild Shattered Scattered Sunshine
       (mildshatteredscatteredsunshine.pass)

Mild Shattered Scattered Sunshine is used to train feedees for
Shattered Scattered Sunshine.  Unlike most training patterns in which
two feedees can be trained simultaneously, for Shattered Scattered
Sunshine, only one feedee is trained at a time.  In Mild Shattered
Scattered Sunshine, the trainer throws diagonal passes and performs
simple hurries rather than hand-offs, while the trainee throws
straight passes and performs hand-offs representative of the feedee
position for Shattered Scattered Sunshine.


----------------------------------------
1.5. Splattered Sunshine  (splatteredsunshine.pass)

This pattern was devised by Eric Sunshine on 2002/12/17.

The basic Splattered Sunshine feed is a three person pattern in which
all jugglers do hand-offs.  The feeder does Ultimates (1-count) with a
hand-off every six beats, and throws diagonal passes.  Feedees A and B
each do pass-pass-self-self with a hand-off, and throw straight passes
to the feeder.  An interesting feature of this pattern is the
irregular hand-off period of the feedees, which toggles between four
and eight beats.

1.5.1. Mild Splattered Sunshine  (mildsplatteredsunshine.pass)

Mild Splattered Sunshine is used to train feedees for Splattered
Sunshine.  Juggler A throws straight passes.  Juggler B throws
diagonal passes.  Although the training pattern does not exactly
replicate the irregular hand-off period of the actual Splattered
Sunshine feedee position, it is sufficiently similar to be of use.


----------------------------------------
2. Other Interesting Patterns

This section illustrates several other interesting patterns.  Some of
these patterns serve as training patterns for the Sunshine Series, and
some of the Sunshine Series patterns were inspired by the patterns in
this section.  For pedagogical purposes, it is recommended that you
view these patterns via the causal editor.


----------------------------------------
2.1. Martin Series

This section describes a set of patterns in which jugglers are forced
to hand-off on a periodic basis.

2.1.1. Martin's Madness  (martinsmadness.pass)

Martin's Madness is a fun feed in which the feeder performs
pass-pass-self and does a hand-off every six beats.  Each feedee
performs Jim's 3-count.  In its basic configuration, the feeder throws
diagonal passes, and the feedees throw straight passes.

2.1.2. Martin's Mildness  (martinsmildness.pass)

In addition to being a training pattern for feeders of Martin's
Madness, Martin's Mildness is also an enjoyable stand-alone pattern.
Each juggler performs pass-pass-self and does a hand-off every six
beats.  One juggler throws straight passes, and the other throws
diagonal passes.

2.1.3. Martin's Ultimates  (martinsultimates.pass)

Martin's Ultimates is an advanced two person pattern in which each
juggler performs Ultimates (1-count) with a hand-off every four beats.
One juggler throws straight passes, and the other throws diagonal
passes.


----------------------------------------
2.2. Jim's 3-Count  (jims3count.pass)

Jim's 3-Count is a variation of the vanilla 3-count pattern.  In this
two person pattern, one juggler throws straight passes, and the other
throws diagonal passes.  Jim's 3-Count plays an important role in more
advanced feeds and is used as a feedee position in Martin's Madness,
Scattered Sunshine, and Very Scattered Sunshine.  An interesting
feature of Jim's 3-Count is that it involves a hurry, in which a
self-throw is made from the same hand that threw a pass on the
previous beat, thus interrupting the normal right-left-right-left
juggling sequence.


----------------------------------------
2.3. Keith's 3-Count Feed  (keiths3countfeed.pass)

Keith's 3-Count feed is an intense feed in which the feeder performs
pass-pass-self and does a hand-off every three beats (twice as often
as in Martin's Madness).  Each feedee performs a 3-count.  Feedee A
always passes to the feeder's right hand, which means that the passes
alternate between straight and diagonal.  Feedee B always passes to
the feeder's left hand.  An interesting feature of this pattern is
that the feeder's hand-off always occurs in only a single direction,
which differs from most patterns in which the direction of the
hand-off alternates.


----------------------------------------
3. Site Swaps

This section demonstrates how to throw various site-swaps (tricks,
such as doubles, triples, and quads) in various patterns and feeds.
For pedagogical purposes, it is recommended that you view these
patterns via the causal editor.


----------------------------------------
3.1. 3-Count: Early Quad  (3count-earlyquad.pass)

This shows how to throw an early quad (which arrives in the other
juggler's hand at the time a normal pass would have arrived) in a
two-person 3-count.


----------------------------------------
3.2. 3-Count: Late Quad  (3count-latequad.pass)

This shows how to throw a late quad (which arrives in the other
juggler's hand one beat later than the normal pass would have arrived)
in a two-person 3-count.


----------------------------------------
3.3. 3-Count Feed: Feedees Throw Late Doubles
     (3countfeed-feedeesthrowlates.pass)

This shows how two feedees can cooperate and throw back-to-back late
doubles to the feeder in a 3-count feed.  The feedees must cooperate
in order to avoid having two clubs arrive at one of the feeder's hands
at a given beat.  The feeder is forced to hand-off from left to right
in order to compensate for the fact that the two expected passes are
arriving a beat late and at the wrong hands.
"

! JoePass file, created Fri Dec 13 16:25:19 2002
!+Header

"This is a simple variation of Shattered Scattered Sunshine feed.  In the basic

feed all jugglers do hand-offs every six beats.  The feeder does Ultimates

(1-count).  Each feedee toggles between 3-count and pass-pass-self every three

beats.  The hand-off for each feedee occurs during the pass-pass-self phase.

In this variation, both feedees always throw straight passes, and the feeder

always throws diagonal passes.  This differs from the basic feed in which one

feedee throws diagonal and one throws straight.  This pattern was devised by

Eric Sunshine <sunshine@ericsunshine.com> on 2002/12/12."



#r PZ (0,0,0)

#r PF (-150,0,0)

#j 1 (150,0,100) PF

#j 2 PF PZ

#j 3 (150,0,-100) PF

!-Header
! cdew siteswap output: 
#sx
#mhn*
#objectCount 9
<( -, 3:2) ( 3:2, 2x*) ( 3*, -) ( -, 3:2) ( 3, -) ( -, 3) ( 3:2, -) ( 2x*, 3:2) ( -, 3*) ( 3:2, -) ( -, 3) ( 3, -) |
( -, 3:1x) ( 3:1x, -) ( -, 3:3x) ( 3:1x, 2x*) ( 3:3x*, -) ( -, 3:3x) ( 3:1x, -) ( -, 3:1x) ( 3:3x, -) ( 2x*, 3:1x) ( -, 3:3x*) ( 3:3x, -) |
( 3*, -) ( -, 3) ( 3:2, -) ( -, 3) ( 3:2, -) ( 2x*, 3:2) ( -, 3*) ( 3, -) ( -, 3:2) ( 3, -) ( -, 3:2) ( 3:2, 2x*) >



"-------------------hide content from JoePass

start of cdew output

cdewSignature Eric Sunshine <sushine@ericsunshine.com>
cdewLastChanged Eric Sunshine <sunshine@ericsunshine.com>

#cdew Version  1.700000

cdewsize 3 2 12
cdewLineMode 0
cdewDisplayMode 0
cdewColorMode 0
cdewCellBackground 1
cdewLineSeperators 0
cdewHandDelay 0
cdewShowNumbers 0
cdewShowHurries 0
cdewShowModifiers 1
cell 0 0 0 = -3 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 0 = 1 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 1 = 1 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 1 = 0 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 2 = 1 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 2 = -3 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 3 = -3 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 3 = 1 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 4 = 1 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 4 = -3 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 5 = -3 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 5 = 1 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 6 = 1 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 6 = -3 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 7 = 0 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 7 = 1 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 8 = -3 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 8 = 1 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 9 = 1 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 9 = -3 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 10 = -3 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 10 = 1 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 0 11 = 1 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 0 1 11 = -3 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 0 = -3 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 0 = 1 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 1 = 1 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 1 = -3 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 2 = -3 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 2 = 1 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 3 = 1 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 3 = 0 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 4 = 1 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 4 = -3 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 5 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 5 = 1 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 6 = 1 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 6 = -3 0 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 7 = -3 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 7 = 1 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 8 = 1 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 8 = -3 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 9 = 0 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 9 = 1 0 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 10 = -3 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 10 = 1 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 0 11 = 1 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 1 1 11 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 0 = 1 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 0 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 1 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 1 = 1 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 2 = 1 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 2 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 3 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 3 = 1 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 4 = 1 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 4 = -3 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 5 = 0 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 5 = 1 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 6 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 6 = 1 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 7 = 1 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 7 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 8 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 8 = 1 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 9 = 1 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 9 = -3 2 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 10 = -3 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 10 = 1 1 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 0 11 = 1 1 1 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
cell 2 1 11 = 0 2 0 -1 1 -1 -1 0 0.000000 0 0 0.000000 0 0 
end of cdew output
-------------------"